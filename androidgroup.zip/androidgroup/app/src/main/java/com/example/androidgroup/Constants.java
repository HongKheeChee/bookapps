package com.example.androidgroup;

public class Constants {

    public static final long MAX_BYTES_PDF = 50000000;
}
